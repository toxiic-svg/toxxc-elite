package com.toxxc.elite

import android.app.Activity
import android.os.Bundle
import android.content.Context
import android.net.wifi.WifiManager
import android.text.format.Formatter
import android.view.Gravity
import android.widget.*
import java.net.InetAddress
import java.util.concurrent.Executors
import kotlin.random.Random

class MainActivity : Activity() {
    private val bg = 0xFF050505.toInt()
    private val green = 0xFF00E676.toInt()
    private val red = 0xFFFF3030.toInt()
    private val white = 0xFFEAEAEA.toInt()
    private lateinit var output: TextView
    private val pool = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 28, 22, 20); setBackgroundColor(bg) }
        val title = TextView(this).apply { text = "T0X!!C  ELITE"; textSize = 30f; setTextColor(green); gravity = Gravity.CENTER; setPadding(0, 12, 0, 6) }
        val sub = TextView(this).apply { text = "ANDROID SECURITY TOOLKIT"; textSize = 12f; setTextColor(red); gravity = Gravity.CENTER; setPadding(0, 0, 0, 22) }
        root.addView(title); root.addView(sub)
        button(root, "DEVICE INFORMATION", green) { showDevice() }
        button(root, "WI-FI NETWORK DETAILS", green) { showWifi() }
        button(root, "DISCOVER DEVICES ON MY WI-FI", red) { discover() }
        button(root, "GENERATE STRONG PASSWORD", green) { output.text = "GENERATED PASSWORD\n\n${password()}" }
        button(root, "SECURITY NOTES", red) { output.text = "SAFETY\n\nOnly test networks and devices you own or have permission to assess.\n\nThis app performs basic local-network reachability checks; it is not a password cracker or vulnerability scanner." }
        output = TextView(this).apply { text = "READY. Choose a tool above."; textSize = 14f; setTextColor(white); setPadding(14, 18, 14, 18); setBackgroundColor(0xFF151515.toInt()) }
        root.addView(output, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun button(parent: LinearLayout, label: String, color: Int, action: () -> Unit) {
        val b = Button(this).apply { text = label; setTextColor(color); setBackgroundColor(0xFF191919.toInt()); isAllCaps = false; textSize = 14f; setOnClickListener { action() } }
        parent.addView(b, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 7 })
    }

    private fun showDevice() {
        output.text = "DEVICE INFORMATION\n\nModel: ${android.os.Build.MODEL}\nManufacturer: ${android.os.Build.MANUFACTURER}\nAndroid: ${android.os.Build.VERSION.RELEASE}\nSDK: ${android.os.Build.VERSION.SDK_INT}\nApp version: 1.0"
    }

    @Suppress("DEPRECATION")
    private fun showWifi() {
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val info = wm.connectionInfo
        val ip = Formatter.formatIpAddress(info.ipAddress)
        output.text = "WI-FI DETAILS\n\nSSID: ${info.ssid ?: "Unavailable"}\nPhone LAN IP: $ip\nLink speed: ${info.linkSpeed} Mbps\n\nAndroid may hide the SSID unless location access is granted."
    }

    @Suppress("DEPRECATION")
    private fun discover() {
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val ipInt = wm.connectionInfo.ipAddress
        if (ipInt == 0) { output.text = "Connect to your own Wi-Fi network first."; return }
        val ip = Formatter.formatIpAddress(ipInt)
        val prefix = ip.substringBeforeLast('.')
        output.text = "Checking local subnet $prefix.0/24 ...\nThis may take a little while."
        pool.execute {
            val found = mutableListOf<String>()
            for (i in 1..254) {
                val host = "$prefix.$i"
                try { if (InetAddress.getByName(host).isReachable(250)) found.add(host) } catch (_: Exception) { }
            }
            runOnUiThread { output.text = "LOCAL NETWORK DISCOVERY\n\nPhone: $ip\nResponsive hosts found: ${found.size}\n\n${found.joinToString("\n").ifEmpty { "No devices replied. Some devices block ping, so this list may be incomplete." }}\n\nUse only on networks you own or are authorized to test." }
        }
    }

    private fun password(): String {
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#%&*_-"
        return (1..20).map { chars[Random.nextInt(chars.length)] }.joinToString("")
    }

    override fun onDestroy() { pool.shutdownNow(); super.onDestroy() }
}
