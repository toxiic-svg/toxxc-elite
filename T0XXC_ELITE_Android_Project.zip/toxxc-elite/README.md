# T0X!!C ELITE Android project

Native Kotlin Android starter app with a black/red/green interface. Includes device information, Wi-Fi details, basic ping-based discovery on the connected local /24 subnet, a random password generator, and safety notes.

## Build

Open this project in Android Studio and build `app` (JDK 17, Android Gradle Plugin 8.7.3). Or push to GitHub and run the `Build T0X!!C Android APK` workflow under Actions. The workflow uploads `app-debug.apk` as an artifact.

## Limitations

The local discovery uses ping reachability and can miss devices that do not respond. This is not a full vulnerability scanner, password cracker, or network intrusion tool. Use only on networks you own or have permission to test.
